package com.spbu.dailycheck

import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class Host(
    val camera: (String, Boolean) -> Unit,
    val gallery: (String, Boolean) -> Unit,
    val pdf: () -> Unit,
    val word: () -> Unit,
    val wa: () -> Unit
)

class MainActivity : ComponentActivity() {

    private val vm: ReportVM by viewModels()

    private var pendingKey: String? = null
    private var pendingPng = false
    private var cameraPath: String? = null

    private val galleryLauncher =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri != null) handleUri(uri)
        }

    private val cameraLauncher =
        registerForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
            val path = cameraPath
            if (ok && path != null) handleUri(Uri.fromFile(File(path)))
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        pendingKey = savedInstanceState?.getString("pk")
        pendingPng = savedInstanceState?.getBoolean("pp") ?: false
        cameraPath = savedInstanceState?.getString("cp")

        vm.loadDefaults(applicationContext)

        val host = Host(
            camera = { key, png -> takePhoto(key, png) },
            gallery = { key, png -> pickGallery(key, png) },
            pdf = { vm.exportPdf(applicationContext) },
            word = { vm.exportWord(applicationContext) },
            wa = { vm.waText = Report.waText(vm) }
        )
        setContent {
            AppTheme {
                App(vm, host)
            }
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString("pk", pendingKey)
        outState.putBoolean("pp", pendingPng)
        outState.putString("cp", cameraPath)
    }

    private fun takePhoto(key: String, png: Boolean) {
        pendingKey = key
        pendingPng = png
        try {
            val dir = File(cacheDir, "camera").apply { mkdirs() }
            val f = File(dir, "foto_${System.currentTimeMillis()}.jpg")
            cameraPath = f.absolutePath
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
            cameraLauncher.launch(uri)
        } catch (e: Exception) {
            Toast.makeText(this, "Kamera tidak tersedia", Toast.LENGTH_SHORT).show()
        }
    }

    private fun pickGallery(key: String, png: Boolean) {
        pendingKey = key
        pendingPng = png
        try {
            galleryLauncher.launch("image/*")
        } catch (e: Exception) {
            Toast.makeText(this, "Galeri tidak tersedia", Toast.LENGTH_SHORT).show()
        }
    }

    private fun handleUri(uri: Uri) {
        val key = pendingKey ?: return
        val png = pendingPng
        lifecycleScope.launch {
            val bytes = withContext(Dispatchers.IO) { Img.load(applicationContext, uri, png) }
            if (bytes == null) {
                Toast.makeText(this@MainActivity, "Gagal membaca gambar", Toast.LENGTH_SHORT).show()
                return@launch
            }
            if (key.startsWith("sig_")) {
                val pad = vm.sigs[key.removePrefix("sig_")]
                val bmp = withContext(Dispatchers.Default) { Img.decode(bytes, 800) }
                if (pad != null && bmp != null) pad.drawImage(bmp)
            } else {
                vm.images[key] = bytes
            }
        }
    }
}
