package com.spbu.dailycheck

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.util.Calendar

val TANKS = listOf("T1", "T2", "T3", "T4", "T5", "T6")
val PRODUCTS = listOf("DEX", "PERTAMAX TURBO", "PERTALITE", "PERTAMAX GREEN 95", "PERTAMAX", "DEXLITE")
val ROMAN = listOf("I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X", "XI", "XII")
val PRODUCT_LOGO = mapOf(
    "DEX" to R.drawable.logo_dex,
    "PERTAMAX TURBO" to R.drawable.logo_pertamax_turbo,
    "PERTALITE" to R.drawable.logo_pertalite,
    "PERTAMAX GREEN 95" to R.drawable.logo_pertamax_green,
    "PERTAMAX" to R.drawable.logo_pertamax,
    "DEXLITE" to R.drawable.logo_dexlite
)
const val DEFAULT_HASIL = "Tidak ditemukan air Pada Manhole dan Tangki Pendam"

class F1Row(val no: String, produk: String) {
    var produk by mutableStateOf(produk)
    var hasil by mutableStateOf(DEFAULT_HASIL)
}

class F2Row(val no: String, produk: String) {
    var produk by mutableStateOf(produk)
    var d1 by mutableStateOf("")
    var d2 by mutableStateOf("")
    var d3 by mutableStateOf("")
    var kualitas by mutableStateOf("On Spec")
}

class F3Row {
    var produk by mutableStateOf("")
    var disp by mutableStateOf("")
    var nozzel by mutableStateOf("")
    var volume by mutableStateOf("")
    var hasil by mutableStateOf("")
}

/** Pilihan nama Ka Shift. Pilihan terakhir = ketik nama sendiri. */
const val KASHIFT_KETIK = "( Ketik Nama )"
val KASHIFT_LIST = listOf("Budi Prasetyo", "Hoeri Rozikin", "Perdi Saputra", "Yayan Aditya Putra")

private const val PREFS = "dailycheck_prefs"
const val DEF_SPBU_NAMA = "SPBU COCO"
const val DEF_SPBU_ALAMAT = "31.107.02 SAMANHUDI"

class SigInfo(val key: String, val label: String, val nama: String, val jabatan: String)

val SIGS = listOf(
    SigInfo("dibuat", "Dibuat", "BUDI PRASETYO", "Ka Shift"),
    SigInfo("diketahui", "Diketahui", "M RADEN JOHAN S", "Pengawas"),
    SigInfo("mengetahui", "Mengetahui", "FERLIQ PONTUMIKA YUDITAMA", "ABH SPBU 31.107.02")
)

/** Papan tanda tangan: digambar langsung ke bitmap transparan. */
class SigPad {
    val bmp: Bitmap = Bitmap.createBitmap(800, 320, Bitmap.Config.ARGB_8888)
    private val canvas = Canvas(bmp)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.BLACK
        strokeWidth = 6f
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    var version by mutableIntStateOf(0)
    var hasInk by mutableStateOf(false)

    fun line(x1: Float, y1: Float, x2: Float, y2: Float) {
        canvas.drawLine(x1, y1, x2, y2, paint)
        hasInk = true
        version++
    }

    fun clear() {
        bmp.eraseColor(0)
        hasInk = false
        version++
    }

    fun drawImage(src: Bitmap) {
        bmp.eraseColor(0)
        val scale = minOf(bmp.width / src.width.toFloat(), bmp.height / src.height.toFloat())
        val w = src.width * scale
        val h = src.height * scale
        val l = (bmp.width - w) / 2f
        val t = (bmp.height - h) / 2f
        canvas.drawBitmap(src, null, RectF(l, t, l + w, t + h), Paint(Paint.FILTER_BITMAP_FLAG))
        hasInk = true
        version++
    }

    fun png(): ByteArray? {
        if (!hasInk) return null
        val out = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.PNG, 100, out)
        return out.toByteArray()
    }
}

class SavedFile(val uriString: String, val name: String, val mime: String)

class ReportVM : ViewModel() {
    var tanggal by mutableStateOf(todayIso())
    var urut by mutableStateOf("001")
    var tab by mutableIntStateOf(0)

    val form1 = TANKS.mapIndexed { i, t -> F1Row(t, PRODUCTS[i]) }
    val form2 = TANKS.mapIndexed { i, t -> F2Row(t, PRODUCTS[i]) }
    val form3 = mutableStateListOf(F3Row(), F3Row())

    /** Foto: kunci -> bytes (JPEG/PNG). Kunci: f1d_0, f1m_0, f2d_0, ut_0, logo */
    val images = mutableStateMapOf<String, ByteArray>()
    val sigs: Map<String, SigPad> = SIGS.associate { it.key to SigPad() }

    var busy by mutableStateOf(false)
    var saved by mutableStateOf<SavedFile?>(null)
    var message by mutableStateOf<String?>(null)
    var waText by mutableStateOf<String?>(null)

    // ---- Ka Shift (pilihan nama atau ketik manual)
    var kashift by mutableStateOf(KASHIFT_LIST[0])
    var kashiftManual by mutableStateOf(false)
    /** Nama Ka Shift yang disimpan sebagai default di HP ini (null = belum ada). */
    var kashiftDefault by mutableStateOf<String?>(null)

    // ---- Header: nama & alamat SPBU (bisa diedit)
    var spbuNama by mutableStateOf(DEF_SPBU_NAMA)
    var spbuAlamat by mutableStateOf(DEF_SPBU_ALAMAT)
    fun spbuNamaOut(): String = spbuNama.trim().ifBlank { DEF_SPBU_NAMA }
    fun spbuAlamatOut(): String = spbuAlamat.trim().ifBlank { DEF_SPBU_ALAMAT }

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun saveKashiftDefault(ctx: Context) {
        val n = kashift.trim()
        if (n.isEmpty()) {
            message = "Nama Ka Shift masih kosong"
            return
        }
        prefs(ctx).edit().putString("kashift", n).apply()
        kashiftDefault = n
        message = "Default Ka Shift di HP ini: $n"
    }

    fun clearKashiftDefault(ctx: Context) {
        prefs(ctx).edit().remove("kashift").apply()
        kashiftDefault = null
        message = "Default Ka Shift dihapus"
    }

    fun saveSpbuDefault(ctx: Context) {
        spbuNama = spbuNamaOut()
        spbuAlamat = spbuAlamatOut()
        prefs(ctx).edit().putString("spbu_nama", spbuNama).putString("spbu_alamat", spbuAlamat).apply()
        message = "Header SPBU disimpan sebagai default"
    }

    fun resetSpbu(ctx: Context) {
        prefs(ctx).edit().remove("spbu_nama").remove("spbu_alamat").apply()
        spbuNama = DEF_SPBU_NAMA
        spbuAlamat = DEF_SPBU_ALAMAT
        message = "Header SPBU dikembalikan ke awal"
    }

    /** Nama untuk kolom tanda tangan ke-[i]; Ka Shift mengikuti pilihan, lainnya tetap. */
    fun namaOf(i: Int): String =
        if (i == 0) kashift.trim().uppercase().ifBlank { "............................" } else SIGS[i].nama

    // ---- Bawaan: logo Pertamina Retail (tanpa tulisan SPBU) & stempel SPBU COCO untuk Ferliq
    private var defaultsLoaded = false

    fun loadDefaults(ctx: Context) {
        if (defaultsLoaded) return
        defaultsLoaded = true
        val sp = prefs(ctx)
        sp.getString("kashift", null)?.takeIf { it.isNotBlank() }?.let {
            kashiftDefault = it
            kashift = it
            kashiftManual = it !in KASHIFT_LIST
        }
        spbuNama = sp.getString("spbu_nama", null) ?: DEF_SPBU_NAMA
        spbuAlamat = sp.getString("spbu_alamat", null) ?: DEF_SPBU_ALAMAT
        applyLogo(ctx)
        applyStamp(ctx)
    }

    fun applyLogo(ctx: Context) {
        images["logo"] = ctx.resources.openRawResource(R.drawable.logo_pertamina_retail).use { it.readBytes() }
    }

    fun applyStamp(ctx: Context) {
        val bmp = BitmapFactory.decodeResource(ctx.resources, R.drawable.logo_spbu_coco) ?: return
        sigs["mengetahui"]?.drawImage(bmp)
    }

    fun urutFmt(): String {
        val d = urut.filter { it.isDigit() }
        return if (d.isEmpty()) "001" else d.padStart(3, '0').takeLast(3)
    }

    fun noDok(): String {
        val p = tanggal.split("-")
        if (p.size != 3) return ""
        val m = p[1].toIntOrNull() ?: return ""
        if (m !in 1..12) return ""
        return "FQQ/${p[2]}${p[1]}${urutFmt()}/3110702/${ROMAN[m - 1]}/${p[0]}"
    }

    fun sigPng(key: String): ByteArray? = sigs[key]?.png()

    fun exportPdf(ctx: Context) = export {
        val name = "Laporan_SPBU_31.107.02_${tanggal.ifBlank { "Dokumen" }}.pdf"
        val uri = Report.savePdf(ctx, this, name)
        SavedFile(uri.toString(), name, "application/pdf")
    }

    fun exportWord(ctx: Context) = export {
        val name = "Laporan_SPBU_31.107.02_${tanggal.ifBlank { "Dokumen" }}.doc"
        val uri = Report.saveWord(ctx, this, name)
        SavedFile(uri.toString(), name, "application/msword")
    }

    private fun export(block: () -> SavedFile) {
        if (busy) return
        busy = true
        viewModelScope.launch {
            try {
                val res = withContext(Dispatchers.IO) { block() }
                saved = res
            } catch (e: Exception) {
                message = "Gagal membuat file: ${e.message}"
            } finally {
                busy = false
            }
        }
    }
}

fun todayIso(): String {
    val c = Calendar.getInstance()
    return "%04d-%02d-%02d".format(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH))
}
