package com.spbu.dailycheck

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.util.Base64
import java.io.OutputStream

object Report {

    private val LABELS = mapOf(
        "DEX" to "Pertamina Dex",
        "PERTAMAX TURBO" to "Pertamax Turbo",
        "PERTALITE" to "Pertalite",
        "PERTAMAX GREEN 95" to "Pertamax Green",
        "PERTAMAX" to "Pertamax",
        "DEXLITE" to "Dexlite"
    )

    // ------------------------------------------------------------------ WhatsApp
    fun waText(vm: ReportVM): String {
        val density = vm.form2.mapIndexed { i, r ->
            val label = LABELS[r.produk] ?: r.produk
            "• Tanki ${i + 1}  $label\n" +
                "   Density : ${r.d1.ifBlank { "-" }}\n" +
                "   Suhu      : ${r.d2.ifBlank { "-" }}\n" +
                "   Hasil       : ${r.d3.ifBlank { "-" }}"
        }.joinToString("\n")

        val tera = vm.form3
            .filter { it.produk.isNotEmpty() || it.disp.isNotEmpty() || it.nozzel.isNotEmpty() || it.hasil.isNotEmpty() }
            .mapIndexed { i, r ->
                val label = LABELS[r.produk] ?: r.produk.ifEmpty { "-" }
                "${i + 1}.  $label, Pulau ${r.disp.ifEmpty { "-" }} ${r.nozzel} = ${r.hasil.ifEmpty { "-" }}"
            }.joinToString("\n")

        val hariTgl = vm.tanggal.ifBlank { "(tanggal belum diisi)" }
        return "Selamat pagi,\n" +
            "Berikut Hasil Tera & Density harian\n" +
            "*${vm.spbuNamaOut()}* ${vm.spbuAlamatOut()}\n" +
            "$hariTgl\n\n" +
            "$density\n\n" +
            "*Hasil Tera*\n" +
            "${tera.ifEmpty { "-" }}\n\n" +
            "Berikut telah disertakan Dokumentasinya\n\n" +
            "Terima kasih."
    }

    // ------------------------------------------------------------------ simpan
    private fun saveToDownloads(ctx: Context, name: String, mime: String, write: (OutputStream) -> Unit): Uri {
        val cv = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, name)
            put(MediaStore.Downloads.MIME_TYPE, mime)
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
        }
        val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)
            ?: throw IllegalStateException("tidak bisa membuat file di Download")
        val os = ctx.contentResolver.openOutputStream(uri)
            ?: throw IllegalStateException("tidak bisa menulis file")
        os.use { write(it) }
        return uri
    }

    fun saveWord(ctx: Context, vm: ReportVM, name: String): Uri {
        val html = buildHtml(ctx, vm)
        return saveToDownloads(ctx, name, "application/msword") { it.write(html.toByteArray(Charsets.UTF_8)) }
    }

    fun savePdf(ctx: Context, vm: ReportVM, name: String): Uri {
        val pdf = PdfWriter(ctx, vm)
        pdf.build()
        return try {
            saveToDownloads(ctx, name, "application/pdf") { pdf.doc.writeTo(it) }
        } finally {
            pdf.doc.close()
        }
    }

    // ------------------------------------------------------------------ HTML (Word)
    private fun esc(s: String): String =
        s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\n", "<br>")

    private fun mimeOf(b: ByteArray): String =
        if (b.size > 3 && b[0] == 0x89.toByte() && b[1] == 'P'.code.toByte()) "image/png" else "image/jpeg"

    private fun imgTag(b: ByteArray?, style: String): String {
        if (b == null) return ""
        val data = Base64.encodeToString(b, Base64.NO_WRAP)
        return "<img src=\"data:${mimeOf(b)};base64,$data\" style=\"$style\"/>"
    }

    fun buildHtml(ctx: Context, vm: ReportVM): String {
        val noDok = vm.noDok()
        val hari = vm.tanggal

        val logoCache = HashMap<String, ByteArray?>()
        fun prodBytes(p: String): ByteArray? = logoCache.getOrPut(p) {
            PRODUCT_LOGO[p]?.let { id -> ctx.resources.openRawResource(id).use { it.readBytes() } }
        }

        fun prodImg(p: String): String =
            imgTag(prodBytes(p), "height:2.5em;max-width:8em;object-fit:contain")

        fun photo(key: String): String {
            val tag = imgTag(vm.images[key], "position:absolute;inset:0;width:100%;height:100%;object-fit:fill")
            return "<div style=\"position:relative;width:100%;height:80px;overflow:hidden\">$tag</div>"
        }

        val sigTags = SIGS.map { imgTag(vm.sigPng(it.key), "height:50px;display:block;margin:0 auto") }
        val sigBlock = """<table style="width:100%;border-collapse:collapse;margin-top:16px">
    <tr>
      <td style="border:1px solid #aaa;padding:8px;text-align:center;width:33%">Dibuat</td>
      <td style="border:1px solid #aaa;padding:8px;text-align:center;width:33%">Diketahui</td>
      <td style="border:1px solid #aaa;padding:8px;text-align:center;width:33%">Mengetahui</td>
    </tr>
    <tr>
      <td style="border:1px solid #aaa;padding:16px 8px;text-align:center;height:70px">${sigTags[0]}</td>
      <td style="border:1px solid #aaa;padding:16px 8px;text-align:center;height:70px">${sigTags[1]}</td>
      <td style="border:1px solid #aaa;padding:16px 8px;text-align:center;height:70px">${sigTags[2]}</td>
    </tr>
    <tr>
      <td style="border:1px solid #aaa;padding:6px 8px;text-align:center"><u>${esc(vm.namaOf(0))}</u><br>${SIGS[0].jabatan}</td>
      <td style="border:1px solid #aaa;padding:6px 8px;text-align:center"><u>${SIGS[1].nama}</u><br>${SIGS[1].jabatan}</td>
      <td style="border:1px solid #aaa;padding:6px 8px;text-align:center"><u>${SIGS[2].nama}</u><br>${SIGS[2].jabatan}</td>
    </tr>
  </table>"""

        val logoHtml = vm.images["logo"]?.let { imgTag(it, "height:60px;max-width:120px;object-fit:contain") }
            ?: """<div style="font-weight:bold;color:#003087;font-size:13px;border:2px solid #003087;padding:4px 10px;border-radius:4px;text-align:center">PERTAMINA<br>RETAIL</div>"""

        fun header(title: String): String = """<div style="text-align:center;margin-bottom:20px">
    <div style="display:flex;align-items:center;justify-content:center;gap:20px">
      <div><div style="font-weight:bold;font-size:15px">$title</div><div style="font-weight:bold;font-size:15px">${esc(vm.spbuAlamatOut())}</div></div>
      $logoHtml
    </div>
    <div style="display:flex;justify-content:space-between;margin-top:12px;font-size:12px">
      <div>Hari/Tanggal: <b>$hari</b></div><div>No Dokumen: <b>$noDok</b></div>
    </div>
  </div>"""

        val td = "border:1px solid #aaa;padding:6px;text-align:center"

        val p1 = vm.form1.mapIndexed { i, r ->
            """<tr>
    <td style="$td;font-weight:bold">${r.no}</td>
    <td style="$td">${prodImg(r.produk)}</td>
    <td style="border:1px solid #aaa;padding:0;text-align:center;height:80px;width:20%">${photo("f1d_$i")}</td>
    <td style="border:1px solid #aaa;padding:0;text-align:center;height:80px;width:20%">${photo("f1m_$i")}</td>
    <td style="border:1px solid #aaa;padding:6px;font-size:11px">${esc(r.hasil)}</td>
  </tr>"""
        }.joinToString("")

        val p2 = vm.form2.mapIndexed { i, r ->
            val warna = if (r.kualitas == "On Spec") "green" else "red"
            """<tr>
    <td style="$td;font-weight:bold">${r.no}</td>
    <td style="$td">${prodImg(r.produk)}</td>
    <td style="border:1px solid #aaa;padding:0;text-align:center;height:80px;width:20%">${photo("f2d_$i")}</td>
    <td style="$td">${esc(r.d1)} / ${esc(r.d2)} / ${esc(r.d3)}</td>
    <td style="$td;color:$warna;font-weight:bold">${r.kualitas}</td>
  </tr>"""
        }.joinToString("")

        val p3 = vm.form3.joinToString("") { r ->
            val prod = if (PRODUCT_LOGO.containsKey(r.produk)) prodImg(r.produk) else esc(r.produk)
            """<tr>
    <td style="$td">$prod</td>
    <td style="$td">${esc(r.disp)}</td>
    <td style="$td">${esc(r.nozzel)}</td>
    <td style="$td">${esc(r.volume)}</td>
    <td style="$td">${esc(r.hasil)}</td>
  </tr>"""
        }

        fun fotoCell(idx: Int): String =
            """<td style="border:1px solid #aaa;padding:6px;width:50%;text-align:center">
            <div style="font-size:11px;color:#555;margin-bottom:4px">Foto ${idx + 1}</div>
            <div style="position:relative;width:100%;height:140px;overflow:hidden;background:#fafafa">${
                imgTag(vm.images["ut_$idx"], "position:absolute;inset:0;width:100%;height:100%;object-fit:fill")
            }</div>
          </td>"""

        val fotoRows = (0..2).joinToString("") { row ->
            "<tr>${fotoCell(row * 2)}${fotoCell(row * 2 + 1)}</tr>"
        }

        val judul = "LAPORAN PEMERIKSAAN KUALITAS DAN KUANTITAS ${esc(vm.spbuNamaOut())}"
        return """<!DOCTYPE html><html><head><meta charset="UTF-8"/>
  <title>Laporan ${esc(vm.spbuNamaOut())}</title>
  <style>body{font-family:Arial,sans-serif;padding:30px;color:#111}table{border-collapse:collapse;width:100%;margin-bottom:10px}th{background:#003087;color:#fff;padding:8px;font-size:12px;text-align:center;border:1px solid #aaa}.page-break{page-break-after:always;margin-bottom:40px}</style>
  </head><body>
  <div class="page-break">
    ${header(judul)}
    <table><tr><th style="width:8%">NO Tangki</th><th style="width:18%">PRODUK</th><th style="width:20%">DOKUMENTASI DIPPING</th><th style="width:20%">DOKUMENTASI MANHOLE</th><th>HASIL PEMERIKSAAN</th></tr>$p1</table>
    $sigBlock
  </div>
  <div class="page-break">
    ${header(judul)}
    <table><tr><th style="width:8%">NO Tangki</th><th style="width:18%">PRODUK</th><th style="width:20%">DOKUMENTASI DENSITY</th><th>HASIL PEMERIKSAAN (Density Obs / Suhu °C / Density 15°C)</th><th style="width:12%">KUALITAS</th></tr>$p2</table>
    $sigBlock
  </div>
  <div>
    ${header(judul)}
    <table><tr><th>PRODUK</th><th style="width:14%">NO. DISPENSER</th><th style="width:14%">NO. NOZZEL</th><th style="width:18%">VOLUME BBM KELUAR</th><th style="width:18%">HASIL UJI TERA</th></tr>$p3</table>
    <div style="margin-top:20px">
      <div style="font-weight:bold;font-size:13px;color:#003087;margin-bottom:8px">Dokumentasi Foto Uji Tera</div>
      <table style="border-collapse:collapse;width:100%">$fotoRows</table>
    </div>
    $sigBlock
  </div>
  </body></html>"""
    }

    // ------------------------------------------------------------------ PDF native
    private class PdfWriter(val ctx: Context, val vm: ReportVM) {
        val doc = PdfDocument()
        private var page: PdfDocument.Page? = null
        private lateinit var c: android.graphics.Canvas
        private var y = 0f
        private var pageNo = 0

        private val PW = 595
        private val PH = 842
        private val M = 30f

        private val noDok = vm.noDok()
        private val logoBmp: Bitmap? = vm.images["logo"]?.let { Img.decode(it) }
        private val prodCache = HashMap<String, Bitmap?>()
        private val sigBmps = SIGS.map { s -> vm.sigPng(s.key)?.let { Img.decode(it) } }

        private fun tp(size: Float, bold: Boolean = false, color: Int = Color.BLACK) =
            TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                textSize = size
                this.color = color
                typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            }

        private val pNormal = tp(9f)
        private val pSmall = tp(8f)
        private val pBold = tp(9f, true)
        private val pTitle = tp(11f, true)
        private val pHead = tp(8f, true, Color.WHITE)
        private val pGreen = tp(9f, true, Color.rgb(0, 128, 0))
        private val pRed = tp(9f, true, Color.RED)
        private val pBlueBold = tp(9f, true, Color.rgb(0, 48, 135))
        private val pLine = Paint().apply {
            color = Color.rgb(170, 170, 170); style = Paint.Style.STROKE; strokeWidth = 0.7f
        }
        private val pBlueFill = Paint().apply { color = Color.rgb(0, 48, 135); style = Paint.Style.FILL }
        private val pBlueLine = Paint().apply {
            color = Color.rgb(0, 48, 135); style = Paint.Style.STROKE; strokeWidth = 1.5f
        }
        private val pBmp = Paint(Paint.FILTER_BITMAP_FLAG)

        private fun prod(p: String): Bitmap? = prodCache.getOrPut(p) {
            PRODUCT_LOGO[p]?.let { BitmapFactory.decodeResource(ctx.resources, it) }
        }

        private fun newPage() {
            page?.let { doc.finishPage(it) }
            pageNo++
            val pg = doc.startPage(PdfDocument.PageInfo.Builder(PW, PH, pageNo).create())
            page = pg
            c = pg.canvas
            y = M
            header()
        }

        private fun ensure(h: Float) {
            if (y + h > PH - M) newPage()
        }

        private fun text(
            s: String, r: RectF, p: TextPaint,
            align: Layout.Alignment = Layout.Alignment.ALIGN_CENTER,
            vCenter: Boolean = true, pad: Float = 4f
        ) {
            if (s.isEmpty()) return
            val w = (r.width() - 2 * pad).toInt().coerceAtLeast(1)
            val sl = StaticLayout.Builder.obtain(s, 0, s.length, p, w).setAlignment(align).build()
            c.save()
            c.clipRect(r)
            val ty = if (vCenter) r.top + (r.height() - sl.height) / 2f else r.top + pad
            c.translate(r.left + pad, maxOf(ty, r.top))
            sl.draw(c)
            c.restore()
        }

        private fun bmp(b: Bitmap?, r: RectF, fit: Boolean) {
            if (b == null) return
            if (!fit) {
                c.drawBitmap(b, null, r, pBmp)
                return
            }
            val pad = 3f
            val aw = r.width() - 2 * pad
            val ah = r.height() - 2 * pad
            val s = minOf(aw / b.width, ah / b.height)
            val w = b.width * s
            val h = b.height * s
            val l = r.left + (r.width() - w) / 2f
            val t = r.top + (r.height() - h) / 2f
            c.drawBitmap(b, null, RectF(l, t, l + w, t + h), pBmp)
        }

        private fun photo(key: String, r: RectF) {
            val b = vm.images[key]?.let { Img.decode(it) }
            bmp(b, r, false)
        }

        private fun header() {
            val titleR = RectF(M, y, PW - M - 120f, y + 44f)
            text(
                "LAPORAN PEMERIKSAAN KUALITAS DAN KUANTITAS ${vm.spbuNamaOut()}\n${vm.spbuAlamatOut()}",
                titleR, pTitle
            )
            val logoR = RectF(PW - M - 110f, y, PW - M, y + 44f)
            if (logoBmp != null) {
                bmp(logoBmp, logoR, true)
            } else {
                val box = RectF(logoR.right - 80f, logoR.top + 4f, logoR.right, logoR.bottom - 4f)
                c.drawRect(box, pBlueLine)
                text("PERTAMINA\nRETAIL", box, pBlueBold)
            }
            y += 54f
            c.drawText("Hari/Tanggal: ${vm.tanggal}", M, y + 9f, pBold)
            val right = "No Dokumen: $noDok"
            c.drawText(right, PW - M - pBold.measureText(right), y + 9f, pBold)
            y += 18f
        }

        private fun headRow(fr: FloatArray, labels: List<String>) {
            val h = 24f
            ensure(h)
            val total = PW - 2 * M
            var x = M
            for (i in fr.indices) {
                val w = total * fr[i]
                val r = RectF(x, y, x + w, y + h)
                c.drawRect(r, pBlueFill)
                c.drawRect(r, pLine)
                text(labels[i], r, pHead, pad = 2f)
                x += w
            }
            y += h
        }

        private fun cells(h: Float, fr: FloatArray, draw: (Int, RectF) -> Unit) {
            ensure(h)
            val total = PW - 2 * M
            var x = M
            for (i in fr.indices) {
                val w = total * fr[i]
                val r = RectF(x, y, x + w, y + h)
                c.drawRect(r, pLine)
                draw(i, r)
                x += w
            }
            y += h
        }

        private fun sigBlock() {
            ensure(130f)
            y += 8f
            val fr = floatArrayOf(1f / 3f, 1f / 3f, 1f / 3f)
            cells(20f, fr) { i, r -> text(SIGS[i].label, r, pNormal) }
            cells(60f, fr) { i, r -> bmp(sigBmps[i], r, true) }
            cells(34f, fr) { i, r -> text("${vm.namaOf(i)}\n${SIGS[i].jabatan}", r, pSmall) }
        }

        fun build() {
            // Form 1
            newPage()
            val f1 = floatArrayOf(.08f, .18f, .22f, .22f, .30f)
            headRow(f1, listOf("NO Tangki", "PRODUK", "DOKUMENTASI DIPPING", "DOKUMENTASI MANHOLE", "HASIL PEMERIKSAAN"))
            vm.form1.forEachIndexed { i, r ->
                cells(78f, f1) { k, rect ->
                    when (k) {
                        0 -> text(r.no, rect, pBold)
                        1 -> bmp(prod(r.produk), rect, true)
                        2 -> photo("f1d_$i", rect)
                        3 -> photo("f1m_$i", rect)
                        else -> text(r.hasil, rect, pSmall, Layout.Alignment.ALIGN_NORMAL)
                    }
                }
            }
            sigBlock()

            // Form 2
            newPage()
            val f2 = floatArrayOf(.08f, .18f, .22f, .40f, .12f)
            headRow(f2, listOf("NO Tangki", "PRODUK", "DOKUMENTASI DENSITY", "HASIL (Density Obs / Suhu C / Density 15C)", "KUALITAS"))
            vm.form2.forEachIndexed { i, r ->
                cells(78f, f2) { k, rect ->
                    when (k) {
                        0 -> text(r.no, rect, pBold)
                        1 -> bmp(prod(r.produk), rect, true)
                        2 -> photo("f2d_$i", rect)
                        3 -> text("${r.d1} / ${r.d2} / ${r.d3}", rect, pNormal)
                        else -> text(r.kualitas, rect, if (r.kualitas == "On Spec") pGreen else pRed)
                    }
                }
            }
            sigBlock()

            // Form 3
            newPage()
            val f3 = floatArrayOf(.24f, .14f, .14f, .24f, .24f)
            headRow(f3, listOf("PRODUK", "NO. DISPENSER", "NO. NOZZEL", "VOLUME BBM KELUAR", "HASIL UJI TERA"))
            vm.form3.forEach { r ->
                cells(32f, f3) { k, rect ->
                    when (k) {
                        0 -> if (PRODUCT_LOGO.containsKey(r.produk)) bmp(prod(r.produk), rect, true)
                        else text(r.produk, rect, pNormal)
                        1 -> text(r.disp, rect, pNormal)
                        2 -> text(r.nozzel, rect, pNormal)
                        3 -> text(r.volume, rect, pNormal)
                        else -> text(r.hasil, rect, pNormal)
                    }
                }
            }
            ensure(30f + 3 * 112f)
            y += 12f
            c.drawText("Dokumentasi Foto Uji Tera", M, y + 9f, pBlueBold)
            y += 16f
            val half = floatArrayOf(.5f, .5f)
            for (row in 0..2) {
                cells(112f, half) { k, rect ->
                    val idx = row * 2 + k
                    text("Foto ${idx + 1}", RectF(rect.left, rect.top, rect.right, rect.top + 14f), pSmall)
                    photo("ut_$idx", RectF(rect.left + 4f, rect.top + 14f, rect.right - 4f, rect.bottom - 4f))
                }
            }
            sigBlock()

            page?.let { doc.finishPage(it) }
            page = null
        }
    }
}
