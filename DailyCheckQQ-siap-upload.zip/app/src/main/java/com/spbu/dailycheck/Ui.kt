package com.spbu.dailycheck

import android.app.DatePickerDialog
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import java.util.Calendar

val PBlue = Color(0xFF003087)
val PRed = Color(0xFFC8102E)
val POrange = Color(0xFFF7941D)
val PGreen = Color(0xFF00A651)
val WaGreen = Color(0xFF25D366)
val PBg = Color(0xFFF0F4F8)

class PhotoTarget(val key: String, val png: Boolean)

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(primary = PBlue, secondary = POrange, error = PRed),
        content = content
    )
}

@Composable
fun App(vm: ReportVM, host: Host) {
    val ctx = LocalContext.current
    var target by remember { mutableStateOf<PhotoTarget?>(null) }
    val ask: (String, Boolean) -> Unit = { key, png -> target = PhotoTarget(key, png) }

    LaunchedEffect(vm.message) {
        vm.message?.let {
            Toast.makeText(ctx, it, Toast.LENGTH_LONG).show()
            vm.message = null
        }
    }

    Scaffold(
        containerColor = PBg,
        bottomBar = { BottomActions(host) }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            Header(vm)
            val titles = listOf("📋 Form 1", "🧪 Form 2", "⛽ Form 3", "✍️ TTD")
            ScrollableTabRow(
                selectedTabIndex = vm.tab,
                edgePadding = 0.dp,
                containerColor = Color.White,
                contentColor = PBlue
            ) {
                titles.forEachIndexed { i, t ->
                    Tab(
                        selected = vm.tab == i,
                        onClick = { vm.tab = i },
                        text = { Text(t, fontSize = 13.sp, maxLines = 1) }
                    )
                }
            }
            Column(
                Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                InfoCard(vm)
                when (vm.tab) {
                    0 -> Form1(vm, ask)
                    1 -> Form2(vm, ask)
                    2 -> Form3(vm, ask)
                    else -> SigTab(vm, ask)
                }
                Spacer(Modifier.height(8.dp))
            }
        }
    }

    // ---- dialog pilih sumber foto
    target?.let { t ->
        val isSig = t.key.startsWith("sig_")
        val has = if (isSig) vm.sigs[t.key.removePrefix("sig_")]?.hasInk == true
        else vm.images.containsKey(t.key)
        AlertDialog(
            onDismissRequest = { target = null },
            title = { Text(if (isSig) "Gambar tanda tangan" else "Foto") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (!isSig) {
                        Button(
                            onClick = { host.camera(t.key, t.png); target = null },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("📷 Ambil dengan Kamera") }
                    }
                    Button(
                        onClick = { host.gallery(t.key, t.png); target = null },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("🖼️ Pilih dari Galeri") }
                    if (has) {
                        OutlinedButton(
                            onClick = {
                                if (isSig) vm.sigs[t.key.removePrefix("sig_")]?.clear()
                                else vm.images.remove(t.key)
                                target = null
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("🗑 Hapus", color = PRed) }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { target = null }) { Text("Batal") } }
        )
    }

    // ---- sedang membuat file
    if (vm.busy) {
        Dialog(onDismissRequest = {}) {
            Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Row(
                    Modifier.padding(20.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    CircularProgressIndicator(Modifier.width(32.dp).height(32.dp))
                    Text("Membuat file…")
                }
            }
        }
    }

    // ---- file tersimpan
    vm.saved?.let { s ->
        AlertDialog(
            onDismissRequest = { vm.saved = null },
            title = { Text("✅ Tersimpan") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("${s.name}\n\nLokasi: folder Download di HP.", fontSize = 13.sp)
                    Button(onClick = { openFile(ctx, s) }, modifier = Modifier.fillMaxWidth()) { Text("📂 Buka") }
                    OutlinedButton(onClick = { shareFile(ctx, s) }, modifier = Modifier.fillMaxWidth()) { Text("📤 Bagikan") }
                }
            },
            confirmButton = { TextButton(onClick = { vm.saved = null }) { Text("Tutup") } }
        )
    }

    // ---- teks WhatsApp
    vm.waText?.let { txt ->
        AlertDialog(
            onDismissRequest = { vm.waText = null },
            title = { Text("💬 Laporan WhatsApp") },
            text = {
                OutlinedTextField(
                    value = txt,
                    onValueChange = { vm.waText = it },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 10,
                    maxLines = 14,
                    textStyle = androidx.compose.ui.text.TextStyle(fontSize = 12.sp)
                )
            },
            confirmButton = {
                Row {
                    TextButton(onClick = { copyText(ctx, txt) }) { Text("📋 Salin") }
                    TextButton(onClick = { shareText(ctx, txt) }) { Text("📤 Kirim") }
                }
            },
            dismissButton = { TextButton(onClick = { vm.waText = null }) { Text("Tutup") } }
        )
    }
}

// ============================================================ bagian umum

@Composable
fun Header(vm: ReportVM) {
    Column(
        Modifier
            .fillMaxWidth()
            .background(PBlue)
            .padding(horizontal = 16.dp, vertical = 10.dp)
    ) {
        Text("PERTAMINA RETAIL", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        Text("Laporan Pemeriksaan Kualitas & Kuantitas", color = Color.White, fontSize = 11.sp)
        Text("${vm.spbuNamaOut()} ${vm.spbuAlamatOut()}", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
    }
}

@Composable
fun BottomActions(host: Host) {
    Surface(shadowElevation = 8.dp, color = Color.White) {
        Row(
            Modifier.fillMaxWidth().padding(8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = host.pdf,
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = PRed)
            ) { Text("🖨️ PDF", fontSize = 12.sp, maxLines = 1) }
            Button(
                onClick = host.word,
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = POrange)
            ) { Text("📄 Word", fontSize = 12.sp, maxLines = 1) }
            Button(
                onClick = host.wa,
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = WaGreen)
            ) { Text("💬 WA", fontSize = 12.sp, maxLines = 1) }
        }
    }
}

@Composable
fun CardBox(content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            content = content
        )
    }
}

@Composable
fun SectionTitle(s: String) {
    Text(s, color = PBlue, fontWeight = FontWeight.Bold, fontSize = 15.sp)
}

@Composable
fun InfoCard(vm: ReportVM) {
    val ctx = LocalContext.current
    CardBox {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Hari/Tanggal:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            OutlinedButton(onClick = { pickDate(ctx, vm.tanggal) { vm.tanggal = it } }) {
                Text(vm.tanggal.ifBlank { "Pilih tanggal" })
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = vm.urut,
                onValueChange = { v -> vm.urut = v.filter { it.isDigit() }.take(3) },
                label = { Text("No Urut") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.width(100.dp)
            )
            Column(Modifier.weight(1f)) {
                Text("No Dokumen", fontSize = 11.sp, color = Color.Gray)
                Text(
                    vm.noDok().ifEmpty { "Pilih tanggal dulu" },
                    fontWeight = FontWeight.Bold,
                    color = PBlue,
                    fontSize = 12.sp
                )
            }
        }
    }
}

fun pickDate(ctx: Context, current: String, onSet: (String) -> Unit) {
    val cal = Calendar.getInstance()
    val p = current.split("-")
    val y = p.getOrNull(0)?.toIntOrNull() ?: cal.get(Calendar.YEAR)
    val m = (p.getOrNull(1)?.toIntOrNull() ?: (cal.get(Calendar.MONTH) + 1)) - 1
    val d = p.getOrNull(2)?.toIntOrNull() ?: cal.get(Calendar.DAY_OF_MONTH)
    DatePickerDialog(ctx, { _, yy, mm, dd ->
        onSet("%04d-%02d-%02d".format(yy, mm + 1, dd))
    }, y, m.coerceIn(0, 11), d).show()
}

@Composable
fun ProductLogo(p: String) {
    val id = PRODUCT_LOGO[p]
    Box(Modifier.fillMaxWidth().height(40.dp), contentAlignment = Alignment.Center) {
        if (id != null) {
            Image(
                painter = painterResource(id),
                contentDescription = p,
                contentScale = ContentScale.Fit,
                modifier = Modifier.fillMaxHeight()
            )
        } else {
            Text("Pilih produk", color = Color.Gray, fontSize = 11.sp)
        }
    }
}

@Composable
fun ProductDropdown(value: String, allowEmpty: Boolean, onSelect: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        OutlinedButton(onClick = { open = true }, modifier = Modifier.fillMaxWidth()) {
            Text(value.ifEmpty { "— Pilih Produk —" }, fontSize = 12.sp, maxLines = 1)
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            if (allowEmpty) {
                DropdownMenuItem(text = { Text("— Pilih Produk —") }, onClick = { onSelect(""); open = false })
            }
            PRODUCTS.forEach { p ->
                DropdownMenuItem(text = { Text(p) }, onClick = { onSelect(p); open = false })
            }
        }
    }
}

@Composable
fun PhotoBox(
    vm: ReportVM,
    key: String,
    label: String,
    height: androidx.compose.ui.unit.Dp,
    modifier: Modifier = Modifier.fillMaxWidth(),
    fit: Boolean = false,
    onClick: () -> Unit
) {
    val shape = RoundedCornerShape(8.dp)
    Box(
        modifier
            .height(height)
            .clip(shape)
            .background(Color(0xFFFAFAFA))
            .border(1.dp, Color(0xFFAAAAAA), shape)
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        val bytes = vm.images[key]
        if (bytes != null) {
            val bmp = remember(bytes) { Img.decode(bytes, 600) }
            if (bmp != null) {
                Image(
                    bitmap = bmp.asImageBitmap(),
                    contentDescription = label,
                    contentScale = if (fit) ContentScale.Fit else ContentScale.FillBounds,
                    modifier = Modifier.fillMaxSize()
                )
            }
        } else {
            Text("📷 $label", fontSize = 12.sp, color = Color.Gray, textAlign = TextAlign.Center)
        }
    }
}

// ============================================================ Form 1

@Composable
fun Form1(vm: ReportVM, ask: (String, Boolean) -> Unit) {
    SectionTitle("Form 1 — Dokumentasi Dipping & Manhole")
    vm.form1.forEachIndexed { i, r ->
        CardBox {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(r.no, color = PBlue, fontWeight = FontWeight.Bold, fontSize = 20.sp, modifier = Modifier.width(40.dp))
                Column(Modifier.weight(1f)) {
                    ProductLogo(r.produk)
                    ProductDropdown(r.produk, false) { r.produk = it }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Column(Modifier.weight(1f)) {
                    Text("Dipping", fontSize = 11.sp, color = Color.Gray)
                    PhotoBox(vm, "f1d_$i", "Foto dipping", 130.dp) { ask("f1d_$i", false) }
                }
                Column(Modifier.weight(1f)) {
                    Text("Manhole", fontSize = 11.sp, color = Color.Gray)
                    PhotoBox(vm, "f1m_$i", "Foto manhole", 130.dp) { ask("f1m_$i", false) }
                }
            }
            OutlinedTextField(
                value = r.hasil,
                onValueChange = { r.hasil = it },
                label = { Text("Hasil pemeriksaan") },
                minLines = 2,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

// ============================================================ Form 2

@Composable
fun Form2(vm: ReportVM, ask: (String, Boolean) -> Unit) {
    SectionTitle("Form 2 — Dokumentasi Density & Kualitas")
    vm.form2.forEachIndexed { i, r ->
        CardBox {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(r.no, color = PBlue, fontWeight = FontWeight.Bold, fontSize = 20.sp, modifier = Modifier.width(40.dp))
                Column(Modifier.weight(1f)) {
                    ProductLogo(r.produk)
                    ProductDropdown(r.produk, false) { r.produk = it }
                }
            }
            PhotoBox(vm, "f2d_$i", "Foto density", 130.dp) { ask("f2d_$i", false) }
            val dec = KeyboardOptions(keyboardType = KeyboardType.Decimal)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(
                    value = r.d1, onValueChange = { r.d1 = it },
                    label = { Text("Density Obs", fontSize = 10.sp, maxLines = 1) },
                    singleLine = true, keyboardOptions = dec, modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = r.d2, onValueChange = { r.d2 = it },
                    label = { Text("Suhu (°C)", fontSize = 10.sp, maxLines = 1) },
                    singleLine = true, keyboardOptions = dec, modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = r.d3, onValueChange = { r.d3 = it },
                    label = { Text("Density 15°C", fontSize = 10.sp, maxLines = 1) },
                    singleLine = true, keyboardOptions = dec, modifier = Modifier.weight(1f)
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("On Spec", "Off Spec").forEach { q ->
                    val sel = r.kualitas == q
                    val col = if (q == "On Spec") PGreen else PRed
                    if (sel) {
                        Button(
                            onClick = { r.kualitas = q },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = col)
                        ) { Text(q) }
                    } else {
                        OutlinedButton(onClick = { r.kualitas = q }, modifier = Modifier.weight(1f)) {
                            Text(q, color = col)
                        }
                    }
                }
            }
        }
    }
}

// ============================================================ Form 3

@Composable
fun Form3(vm: ReportVM, ask: (String, Boolean) -> Unit) {
    SectionTitle("Form 3 — Uji Tera Nozzel")
    vm.form3.forEachIndexed { i, r ->
        CardBox {
            Text("Baris ${i + 1}", color = POrange, fontWeight = FontWeight.Bold)
            ProductLogo(r.produk)
            ProductDropdown(r.produk, true) { r.produk = it }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = r.disp, onValueChange = { r.disp = it },
                    label = { Text("No. Dispenser", fontSize = 11.sp, maxLines = 1) },
                    singleLine = true, modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = r.nozzel, onValueChange = { r.nozzel = it },
                    label = { Text("No. Nozzel", fontSize = 11.sp, maxLines = 1) },
                    singleLine = true, modifier = Modifier.weight(1f)
                )
            }
            OutlinedTextField(
                value = r.volume, onValueChange = { r.volume = it },
                label = { Text("Volume BBM keluar") },
                singleLine = true, modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = r.hasil, onValueChange = { r.hasil = it },
                label = { Text("Hasil uji tera") },
                singleLine = true, modifier = Modifier.fillMaxWidth()
            )
        }
    }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(
            onClick = { vm.form3.add(F3Row()) },
            modifier = Modifier.weight(1f),
            colors = ButtonDefaults.buttonColors(containerColor = POrange)
        ) { Text("➕ Tambah Baris", fontSize = 12.sp, maxLines = 1) }
        Button(
            onClick = { if (vm.form3.size > 1) vm.form3.removeAt(vm.form3.size - 1) },
            modifier = Modifier.weight(1f),
            colors = ButtonDefaults.buttonColors(containerColor = PRed)
        ) { Text("➖ Hapus Terakhir", fontSize = 12.sp, maxLines = 1) }
    }

    CardBox {
        Text("📷 Dokumentasi Foto Uji Tera", color = PBlue, fontWeight = FontWeight.Bold)
        for (row in 0..2) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                for (k in 0..1) {
                    val idx = row * 2 + k
                    Column(Modifier.weight(1f)) {
                        Text("Foto ${idx + 1}", fontSize = 11.sp, color = Color.Gray)
                        PhotoBox(vm, "ut_$idx", "Foto ${idx + 1}", 120.dp) { ask("ut_$idx", false) }
                    }
                }
            }
        }
    }
}

// ============================================================ Tanda tangan

@Composable
fun SigTab(vm: ReportVM, ask: (String, Boolean) -> Unit) {
    val ctx = LocalContext.current
    SectionTitle("Tanda Tangan & Logo")
    CardBox {
        Text("🏪 Header Nama & Alamat SPBU", color = PBlue, fontWeight = FontWeight.Bold)
        Text("Tampil di header Form 1, 2, 3 (PDF/Word), judul aplikasi, dan teks WhatsApp.", fontSize = 11.sp, color = Color.Gray)
        OutlinedTextField(
            value = vm.spbuNama, onValueChange = { vm.spbuNama = it },
            label = { Text("Nama SPBU") }, singleLine = true, modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = vm.spbuAlamat, onValueChange = { vm.spbuAlamat = it },
            label = { Text("Alamat / Kode SPBU") }, singleLine = true, modifier = Modifier.fillMaxWidth()
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { vm.saveSpbuDefault(ctx) }) { Text("⭐ Jadikan Default") }
            OutlinedButton(onClick = { vm.resetSpbu(ctx) }) { Text("↺ Awal", color = PRed) }
        }
    }
    CardBox {
        Text("🏢 Logo Pertamina Retail", color = PBlue, fontWeight = FontWeight.Bold)
        Text("Tampil di header Form 1, 2, dan 3 pada PDF/Word.", fontSize = 11.sp, color = Color.Gray)
        PhotoBox(vm, "logo", "Upload logo", 90.dp, fit = true) { ask("logo", true) }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (vm.images.containsKey("logo")) {
                OutlinedButton(onClick = { vm.images.remove("logo") }) { Text("🗑 Hapus Logo", color = PRed) }
            }
            OutlinedButton(onClick = { vm.applyLogo(ctx) }) { Text("↺ Logo Standar", color = PBlue) }
        }
    }
    SIGS.forEach { s ->
        val pad = vm.sigs.getValue(s.key)
        CardBox {
            Text(s.label, color = PBlue, fontWeight = FontWeight.Bold)
            SignaturePad(pad)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TextButton(onClick = { pad.clear() }) { Text("Hapus", color = PRed) }
                TextButton(onClick = { ask("sig_${s.key}", true) }) { Text("Upload Gambar", color = PBlue) }
                if (s.key == "mengetahui") {
                    TextButton(onClick = { vm.applyStamp(ctx) }) { Text("Stempel SPBU COCO", color = PBlue) }
                }
            }
            if (s.key == "dibuat") {
                KashiftPicker(vm)
            } else {
                Text(
                    s.nama, fontWeight = FontWeight.Bold, fontSize = 13.sp,
                    modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center
                )
            }
            Text(
                s.jabatan, fontSize = 12.sp, color = Color.Gray,
                modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center
            )
        }
    }
    Text(
        "💡 Gambar tanda tangan langsung di kotak abu-abu dengan jari, atau pilih Upload Gambar. Tekan Hapus untuk mengulang.",
        fontSize = 12.sp, color = Color.DarkGray
    )
}

/** Pilihan nama Ka Shift: 4 nama + "( Ketik Nama )" untuk mengetik sendiri. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun KashiftPicker(vm: ReportVM) {
    var expanded by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = it }) {
            OutlinedTextField(
                value = if (vm.kashiftManual) KASHIFT_KETIK else vm.kashift,
                onValueChange = {},
                readOnly = true,
                label = { Text("Nama Ka Shift") },
                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                modifier = Modifier.menuAnchor().fillMaxWidth()
            )
            ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                KASHIFT_LIST.forEach { n ->
                    DropdownMenuItem(
                        text = { Text(n) },
                        onClick = { vm.kashift = n; vm.kashiftManual = false; expanded = false }
                    )
                }
                DropdownMenuItem(
                    text = { Text(KASHIFT_KETIK) },
                    onClick = {
                        if (!vm.kashiftManual) vm.kashift = ""
                        vm.kashiftManual = true
                        expanded = false
                    }
                )
            }
        }
        if (vm.kashiftManual) {
            OutlinedTextField(
                value = vm.kashift,
                onValueChange = { vm.kashift = it },
                label = { Text("Ketik nama Ka Shift") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        }
        val ctx = LocalContext.current
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Button(onClick = { vm.saveKashiftDefault(ctx) }) { Text("⭐ Jadikan Default") }
            if (vm.kashiftDefault != null) {
                TextButton(onClick = { vm.clearKashiftDefault(ctx) }) { Text("Hapus Default", color = PRed) }
            }
        }
        Text(
            vm.kashiftDefault?.let { "Default di HP ini: $it" } ?: "Belum ada default — nama akan kembali ke Budi Prasetyo saat aplikasi dibuka.",
            fontSize = 11.sp, color = Color.Gray
        )
        Text(
            "Ka Shift", fontSize = 12.sp, color = Color.Gray,
            modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center
        )
    }
}

@Composable
fun SignaturePad(pad: SigPad) {
    val image = remember(pad) { pad.bmp.asImageBitmap() }
    Canvas(
        Modifier
            .fillMaxWidth()
            .aspectRatio(2.5f)
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0xFFF2F2F2))
            .border(1.dp, Color(0xFFAAAAAA), RoundedCornerShape(8.dp))
            .pointerInput(pad) {
                var last: Offset? = null
                detectDragGestures(
                    onDragStart = { o -> last = o },
                    onDragEnd = { last = null },
                    onDragCancel = { last = null },
                    onDrag = { change, _ ->
                        change.consume()
                        val a = last
                        val b = change.position
                        if (a != null) {
                            val sx = pad.bmp.width / size.width.toFloat()
                            val sy = pad.bmp.height / size.height.toFloat()
                            pad.line(a.x * sx, a.y * sy, b.x * sx, b.y * sy)
                        }
                        last = b
                    }
                )
            }
    ) {
        @Suppress("UNUSED_VARIABLE")
        val v = pad.version
        drawImage(image, dstSize = IntSize(size.width.toInt(), size.height.toInt()))
    }
}

// ============================================================ aksi file / teks

fun openFile(ctx: Context, s: SavedFile) {
    val i = Intent(Intent.ACTION_VIEW)
        .setDataAndType(Uri.parse(s.uriString), s.mime)
        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
    try {
        ctx.startActivity(i)
    } catch (e: ActivityNotFoundException) {
        Toast.makeText(ctx, "Tidak ada aplikasi pembuka. File ada di folder Download.", Toast.LENGTH_LONG).show()
    }
}

fun shareFile(ctx: Context, s: SavedFile) {
    val i = Intent(Intent.ACTION_SEND)
        .setType(s.mime)
        .putExtra(Intent.EXTRA_STREAM, Uri.parse(s.uriString))
        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    ctx.startActivity(Intent.createChooser(i, "Bagikan").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}

fun copyText(ctx: Context, text: String) {
    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cm.setPrimaryClip(ClipData.newPlainText("laporan", text))
    Toast.makeText(ctx, "Tersalin!", Toast.LENGTH_SHORT).show()
}

fun shareText(ctx: Context, text: String) {
    val i = Intent(Intent.ACTION_SEND)
        .setType("text/plain")
        .putExtra(Intent.EXTRA_TEXT, text)
    ctx.startActivity(Intent.createChooser(i, "Kirim laporan").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}
